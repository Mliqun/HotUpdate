﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

namespace U3DUtility
{
    [RequireComponent(typeof(CharacterController))]
    class TPController : MonoBehaviour
    {

    }
}
